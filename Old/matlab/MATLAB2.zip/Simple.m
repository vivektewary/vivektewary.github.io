function I = Simple(f,a,b)

I = ((b-a)/6)*(f(a)+4*f((b+a)/2)+f(b));